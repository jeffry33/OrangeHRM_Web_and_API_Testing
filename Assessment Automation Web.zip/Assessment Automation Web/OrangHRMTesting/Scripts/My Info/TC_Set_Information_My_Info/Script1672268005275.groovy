import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.openBrowser('')

WebUI.navigateToUrl('https://opensource-demo.orangehrmlive.com/web/index.php/auth/login')

WebUI.setText(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object Login/input_Username_username'), 'Admin')

WebUI.setEncryptedText(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object Login/input_Password_password'), 'hUKwJTbofgPU9eVlw/CnDQ==')

WebUI.click(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object Login/button_Login'))

WebUI.delay(2)

WebUI.click(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/Select_My Info'))

WebUI.setText(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/input_Nickname_My_info'), 'OJ')

WebUI.setText(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/input_Other Id_My_Info'), '00123')

WebUI.setText(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/input_Driver_license_number_My_info'), 
    '31000231231234')

WebUI.click(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/Dropdown_License Expiry Date_My_info'))

WebUI.delay(2)

WebUI.click(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/Select_Value_License_Date'))

WebUI.setText(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/input_SSN Number_My_info'), 'SSN022')

WebUI.setText(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/input_SIN Number_My_Info'), 'SIN022')

WebUI.setText(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/input_Military_my_info'), 'V2')

WebUI.click(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/button_Save_Military_service_my_info'))

WebUI.verifyElementPresent(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/Verify_notif_Personal_Detail_Success'), 
    0)

WebUI.delay(5)

WebUI.click(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/Dropdown_blood_type_my_info'))

WebUI.delay(2)

WebUI.click(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/Select_label_blood_type_A_my_info'))

WebUI.click(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/button_Save_custom_field'))

WebUI.verifyElementPresent(findTestObject('Sharing_Vision_Technical_Test/OrangeHRM/Object_My_Info/Verify_notif_Blood_Type_Success'), 
    0)

WebUI.takeFullPageScreenshot()

WebUI.delay(2)

WebUI.closeBrowser()

