<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>upload file</name>
   <tag></tag>
   <elementGuidId>e942d264-8376-4ecd-af61-160a998f7bff</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'oxd-file-input']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>oxd-file-input</value>
      <webElementGuid>91d74e5a-0537-49ac-9251-40d779edd37b</webElementGuid>
   </webElementProperties>
</WebElementEntity>
