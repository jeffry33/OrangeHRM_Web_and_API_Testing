<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>Object linda</name>
   <tag></tag>
   <elementGuidId>e6088038-65f8-4237-b119-257ba8619e43</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>.//div[contains(@class, 'oxd-select-option')][1]
</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'oxd-select-option']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>oxd-select-option</value>
      <webElementGuid>fd2d2d7e-f4b3-457d-8d5c-02a94f0c9745</webElementGuid>
   </webElementProperties>
</WebElementEntity>
